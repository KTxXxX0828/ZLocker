written in cmd
pass:unlock

dir:c:\ProgramData\locker (dir is auto generate when you launch app)

made by ptr35